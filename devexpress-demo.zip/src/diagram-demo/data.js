export const nodeData = [
  {
    id: 1,
    type: 'corporation_partnership',
    region: 'us',
    investment: 'inv1',
    legalEntity: 'le1',
    skip: false,
    color: ''
  },
  {
    id: 2,
    type: 'corporation_partnership',
    region: 'us',
    investment: 'inv2',
    legalEntity: 'le2',
    skip: false,
    color: ''
  }
]

export const edgeData = [
  {
    id: 1,
    from: 1,
    to: 2
  }
]

export const regions = [
  { id: 'us', label: 'US' },
  { id: 'in', label: 'IND' },
  { id: 'uk', label: 'UK' }
]

export const legalEntites = [
  { id: 'le1', label: 'NH Bridge Point North Property Owner Demo LLC' },
  { id: 'le2', label: 'MA Bridge Point North Property Owner Demo LLC' },
  { id: 'le3', label: 'NY Bridge Point North Property Owner Demo LLC' },
]

export const investments = [
  {id: 'inv1', label: 'All Investments' },
  {id: 'inv2', label: 'Demo Investment 1' },
  {id: 'inv3', label: 'Demo Investment 2' },
]