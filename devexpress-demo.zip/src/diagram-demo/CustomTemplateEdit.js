import React from 'react';
import { v4 as uuid } from 'uuid';
// import ArrayStore from 'devextreme/data/array_store';
import EditNodePopup from './EditNodePopup';
import { nodeData, edgeData, legalEntites, investments, regions } from './data';
const DevExpress = window.DevExpress;

const entityShapes = [
  {
    type: "branch",
    category: "entities",
    baseType: "ellipse",
    allowEditText: false
  },
  {
    type: "corporation",
    category: "entities",
    baseType: "rectangle",
    allowEditText: false
  },
  {
    type: "corporation_partnership",
    category: "entities",
    baseType: "rectangle",
    allowEditText: false
  },
  {
    type: "disregarded_corporation",
    category: "entities",
    baseType: "rectangle",
    allowEditText: false
  },
  {
    type: "disregarded_partnership",
    category: "entities",
    baseType: "triangle",
    allowEditText: false
  },
  {
    type: "partnership_corporation",
    category: "entities",
    baseType: "rectangle",
    allowEditText: false
  },
  {
    type: "partnership_partnership",
    category: "entities",
    baseType: "triangle",
    allowEditText: false
  }
]

function customShapeToolboxTemplate(item, $container) {
  const { type } = item;
  let $content = '<svg></svg>';
  switch (type) {
    case 'corporation_partnership':
      $content = `
        <svg>
          <line x1="0%" y1="0%" x2="50%" y2="100%" />
          <line x1="100%" y1="0%" x2="50%" y2="100%" />
        </svg>
      `;
      break;
    case 'partnership_corporation':
      $content = `
        <svg>
          <line x1="50%" y1="0%" x2="0%" y2="100%" />
          <line x1="50%" y1="0%" x2="100%" y2="100%" />
        </svg>
      `;
      break;
    case 'disregarded_corporation':
      $content = `
        <svg>
          <ellipse cx="50%" cy="50%" rx="50%" ry="50%" />
        </svg>
      `;
      break;
    case 'disregarded_partnership':
      $content = `
        <svg>
          <ellipse cx="50%" cy="68%" rx="30%" ry="30%" />
        </svg>
      `;
      break;
    default:
      break;
  }
  $container.append($content);
}

function customShapeTemplate(item, $container) {
  customShapeToolboxTemplate(item, $container);
}

class CustomTemplateEdit extends React.Component {

  constructor(props) {
    super(props);
    this.nodeSource = new DevExpress.data.ArrayStore({
      key: 'id',
      data: [],
      onInserting: function (values) {
        values.id = values.id || uuid();
        values.region = values.region || "";
        values.investment = values.investment || "";
        values.legalEntity = values.legalEntity || '';
      }
    })
    this.edgeSource = new DevExpress.data.ArrayStore({
      key: 'id',
      data: []
    });
    this.state = {
      showEditNodePopup: false,
      selectedNodeItem: {},
      readOnly: false,
    }
  }

  componentDidMount() {
    const _this = this;
    this.diagramRef = window.$('#custom-template-edit-demo').dxDiagram({
      readOnly: _this.state.readOnly,
      customShapes: [...entityShapes],
      customShapeToolboxTemplate: customShapeToolboxTemplate,
      customShapeTemplate: customShapeTemplate,
      onItemDblClick: _this.onNodeDblClick,
      onRequestLayoutUpdate: _this.onRequestLayoutUpdate,
      onRequestEditOperation: _this.onRequestEditOperation,
      onCustomCommand: _this.onCustomCommand,
      selectionChanged: _this.selectionChanged,
      contentReady: _this.contentReady,
      toolbox: {
        showSearch: false,
        shapeIconsPerRow: 1,
        groups: [
          { category: 'entities', title: 'Entities' }
        ]
      },
      nodes: {
        dataSource: _this.nodeSource,
        keyExpr: 'id',
        typeExpr: _this.typeExpr,
        textExpr: _this.textExpr,
        styleExpr: _this.styleExpr,
        textStyleExpr: _this.textStyleExpr,
        leftExpr: 'x',
        topExpr: 'y',
        customDataExpr: function (obj, value) {
          if (value === undefined) {
            return {
              type: obj.type,
              region: obj.region,
              legalEntity: obj.legalEntity,
              investment: obj.investment
            };
          } else {
            obj.type = value.type;
            obj.region = value.region;
            obj.legalEntity = value.legalEntity;
            obj.investment = value.investment;
          }
        },
        autoSizeEnabled: true,
        autoLayout: {
          type: 'layered'
        }
      },
      edges: {
        dataSource: _this.edgeSource,
        keyExpr: 'id',
        fromExpr: 'from',
        toExpr: 'to'
      },
      historyToolbar: {
        visible: false
      },
      viewToolbar: {
        visible: false,
      },
      mainToolbar: {
        visible: true,
        commands: [
          { name: "undo" },
          { name: "redo" },
          { name: "separator" },
          { name: "fontName" },
          { name: "fontSize" },
          { name: "separator" },
          { name: "bold" },
          { name: "italic" },
          { name: "underline" },
          { name: "separator" },
          { name: "fontColor" },
          { name: "lineColor" },
          { name: "fillColor" },
          { name: "separator" },
          { name: 'zoomLevel' },
          { name: 'fullScreen' },
          { name: "separator" },
          { name: "export", icon: "export", items: ["exportSvg", "exportPng", "exportJpg", { name: 'exportJson', text: 'Export to JSON' }] },
          { name: 'import', icon: 'paste', text: 'Import' },
          { name: 'separator' },
          { name: "readOnly", icon: "edit", text: "Make Read Only" },
          { name: "clear", icon: "clearsquare", text: "Clear Diagram" }
        ]
      }
    }).dxDiagram("instance")
    this.diagramRef.on('selectionChanged', _this.selectionChanged)
  }

  onNodeDblClick = ({ item }) => {
    this.setState({
      selectedNodeItem: Object.assign({}, item.dataItem),
      showEditNodePopup: true,
    })
  }

  textExpr = props => {
    const { investment, region, legalEntity } = props;
    return `${regions.find(r => r.id === region)?.label || ''} - ${legalEntites.find(le => le.id === legalEntity)?.label || ''} - ${investments.find(inv => inv.id === investment)?.label || ''}`;
  }

  typeExpr = (props, x) => {
    return props.type;
  };

  // update these functions
  styleExpr = props => {
    return props.style;
  }

  textStyleExpr = props => {
    return props.styleText;
  }

  onCustomCommand = ({ name }) => {
    if (name === 'exportJson') {
      this.export = this.diagramRef.export();
      console.log(JSON.parse(this.export))
      const shapes = JSON.parse(this.diagramRef.export()).shapes;     
      this.nodeSource._array.forEach(n => {
        const shape = shapes.find(item => item.dataKey === n.id)
        const { style, styleText, type, x, y } = shape;
        n.style = style;
        n.styleText = styleText;
        n.type = type;
        n.x = x;
        n.y = y;
      });
      this.savedData = {
        nodes: JSON.parse(JSON.stringify(this.nodeSource._array)),
        edges: JSON.parse(JSON.stringify(this.edgeSource._array))
      };
    } else if (name === 'clear') {
      this.diagramRef.import('')
    } else if (name === 'readOnly') {
      this.setState({
        readOnly: !this.state.readOnly
      })
      this.diagramRef.readOnly = true;
      this.diagramRef._updateReadOnlyState();
    } else if (name === 'import') {
      this.diagramRef.import(this.export)
      // this.nodeSource.push(
      //   this.savedData.nodes.map(n => ({
      //     type: 'insert',
      //     data: { ...n },
      //     key: n.id
      //   }))
      // )
      // this.edgeSource.push(
      //   this.savedData.edges.map(n => ({
      //     type: 'insert',
      //     data: { ...n },
      //     key: n.id
      //   }))
      // )
    }
  }

  onRequestLayoutUpdate = e => {
    // console.log('x->', e)
  }

  onRequestEditOperation = e => {
    // console.log('y->', e);
  }

  selectionChanged = e => {
    // console.log('e-->', e)
  }

  contentReady = e => {
    // console.log(e);
  }

  saveUpdate = (item) => {
    this.nodeSource.push([
      {
        type: 'update',
        key: this.state.selectedNodeItem.id,
        data: {
          ...item
        }
      }
    ])
    this.setState({
      selectedNodeItem: {},
      showEditNodePopup: false,
    })
  }
  
  cancelUpdate = () => {
    this.setState({
      selectedNodeItem: {},
      showEditNodePopup: false,
    })
  }

  render() {
    return (
      <div>
        <div id="custom-template-edit-demo"></div>
        <EditNodePopup
          visible={this.state.showEditNodePopup}
          nodeItem={this.state.selectedNodeItem}
          saveUpdate={this.saveUpdate}
          cancelUpdate={this.cancelUpdate}
          regions={regions}
          investments={investments}
          legalEntites={legalEntites}
        />
      </div>
    );
  }
}

export default CustomTemplateEdit;
